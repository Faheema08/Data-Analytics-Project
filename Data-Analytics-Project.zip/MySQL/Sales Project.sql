create database Sales;

 select * from customers; 
  select * from products; 
   select * from sales; 
   
   SELECT  
    DATE_FORMAT(
    STR_TO_DATE(s.SaleDate, '%c/%e/%Y'),'%Y-%m') AS Month, 
    SUM(p.UnitPrice * s.Quantity) AS Revenue 
FROM Sales s 
JOIN Products p ON s.ProductID = p.ProductID 
where STR_TO_DATE(s.SaleDate, '%c/%e/%Y') is not null
GROUP BY Month 
ORDER BY Month; 

SELECT  
    p.ProductName, 
    SUM(s.Quantity) AS TotalSold 
FROM Sales s 
JOIN Products p ON s.ProductID = p.ProductID 
GROUP BY p.ProductName 
ORDER BY TotalSold DESC;

SELECT  
  c.CustomerID,
    c.Name, 
    SUM(p.UnitPrice * s.Quantity) AS TotalSpent 
FROM Sales s 
JOIN Customers c ON s.CustomerID = c.CustomerID 
JOIN Products p ON s.ProductID = p.ProductID 
GROUP BY c.CustomerID,c.Name
ORDER BY TotalSpent DESC;

